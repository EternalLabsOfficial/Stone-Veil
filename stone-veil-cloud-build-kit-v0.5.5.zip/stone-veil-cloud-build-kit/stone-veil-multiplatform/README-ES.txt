STONE VEIL 0.5.5 — PAQUETE MULTIPLATAFORMA

Incluye:
- desktop/: proyecto Electron para generar instaladores Windows, macOS y Linux.
- android/: proyecto Android Studio para generar un APK.
- La versión HTML original de navegador se mantiene aparte para itch.io.

IMPORTANTE SOBRE LOS GUARDADOS
Cada instalación/app mantiene sus propios datos locales. Los guardados de itch.io
no se transfieren automáticamente a la aplicación instalada, porque el navegador
y la app tienen almacenamientos separados. Las partidas dentro de cada app sí
se conservan al actualizar normalmente la app, siempre que se mantenga el mismo
identificador de aplicación y no se borren sus datos.

WINDOWS / macOS / LINUX
1. Instala Node.js LTS.
2. Abre una terminal dentro de desktop/.
3. Ejecuta: npm install
4. En el sistema destino ejecuta uno de estos comandos:
   npm run dist:win   (Windows: genera instalador NSIS y portable)
   npm run dist:mac   (macOS: genera DMG y ZIP; compilar en Mac)
   npm run dist:linux (Linux: genera AppImage y DEB)

ANDROID
1. Abre la carpeta android/ con Android Studio.
2. Deja que Gradle sincronice y descargue los componentes requeridos.
3. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Para distribuirlo ampliamente, firma el APK desde Build > Generate Signed Bundle / APK.

LIMITACIONES DE DISTRIBUCIÓN
Este paquete contiene los proyectos fuente y el juego integrado, no los binarios
finales .exe/.dmg/.AppImage/.apk. Los instaladores deben compilarse en los entornos
correspondientes. macOS normalmente requiere firma/notarización para evitar avisos
de Gatekeeper al distribuir fuera de la App Store.

ITCH.IO
Conserva y actualiza por separado el HTML de navegador. No reemplaces la página
Browser Game por estos proyectos; puedes añadir los instaladores como descargas.
